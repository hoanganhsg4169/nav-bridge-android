package com.gpsble.bridge

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.gpsble.bridge.BleManager.logLiveData

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val scanGranted = permissions[Manifest.permission.BLUETOOTH_SCAN] ?: false
        val connectGranted = permissions[Manifest.permission.BLUETOOTH_CONNECT] ?: false
        val locationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false

        if (scanGranted && connectGranted) {
            addToLog("Đã cấp đầy đủ quyền Ble. Sẵn sàng quét.")
        } else {
            addToLog("Thiếu một số quyền BLE. Vui lòng cấp lại.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Khởi tạo BleManager với local context
        BleManager.init(applicationContext)

        setContent {
            MainScreen(
                onGrantNotificationClick = { requestNotificationAccess() },
                onScanConnectClick = { startBleProcess() },
                onClearLogClick = { BleManager.clearLog() }
            )
        }
        
        checkAndRequestPermissions()
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_SCAN)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    private fun requestNotificationAccess() {
        if (!isNotificationServiceEnabled()) {
            addToLog("Yêu cầu Notification Access. Đang mở trang Cài đặt...")
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        } else {
            addToLog("Quyền Notification Access đã được cấp trước đó.")
            Toast.makeText(this, "Quyền đã được cấp!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val pkgName = packageName
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        if (!TextUtils.isEmpty(flat)) {
            val names = flat.split(":")
            for (name in names) {
                val cn = ComponentName.unflattenFromString(name)
                if (cn != null && TextUtils.equals(pkgName, cn.packageName)) {
                    return true
                }
            }
        }
        return false
    }

    private fun startBleProcess() {
        addToLog("Bắt đầu quét thiết bị ESP32...")
        BleManager.startScanAndConnect()
    }

    private fun addToLog(msg: String) {
        BleManager.addLog(msg)
    }
}

@Composable
fun MainScreen(
    onGrantNotificationClick: () -> Unit,
    onScanConnectClick: () -> Unit,
    onClearLogClick: () -> Unit
) {
    var logs by remember { mutableStateOf(emptyList<String>()) }
    
    // Đăng ký nhận log theo thời gian thực
    DisposableEffect(Unit) {
        val observer: (List<String>) -> Unit = { updatedLogs ->
            logs = updatedLogs
        }
        logLiveData.add(observer)
        onDispose {
            logLiveData.remove(observer)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)) // Slate 900
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Header
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "MAPS BLE BRIDGE",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = Color(0xFF38BDF8), // Sky 400
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = "Bộ truyền dữ liệu chỉ đường từ Google Maps sang ESP32",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8) // Slate 400
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Action Buttons
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onGrantNotificationClick,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)), // Sky 600
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("1. Cấp quyền truy cập thông báo", color = Color.White, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onScanConnectClick,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)), // Emerald 500
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("2. Quét & Kết nối BLE (ESP32)", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Terminal Log Console
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "System Console Log",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFFF1F5F9)
                )
                TextButton(onClick = onClearLogClick) {
                    Text("Xóa log", color = Color(0xFFEF4444), fontSize = 12.sp)
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF020617), shape = RoundedCornerShape(12.dp)) // Slate 950
                    .border(1.dp, Color(0xFF334155), shape = RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    reverseLayout = true
                ) {
                    items(logs.reversed()) { log ->
                        Text(
                            text = log,
                            color = if (log.contains("gửi", true)) Color(0xFFFFD700) 
                                   else if (log.contains("kết nối", true)) Color(0xFF10B981)
                                   else if (log.contains("lỗi", true)) Color(0xFFEF4444)
                                   else Color(0xFF94A3B8),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

package com.gpsble.bridge

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MapsNotificationService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val packageName = sbn?.packageName ?: return
        
        // Lọc chính xác thông báo đến từ Google Maps 
        if (packageName == "com.google.android.apps.maps") {
            val extras = sbn.notification?.extras ?: return
            
            // Trích xuất Tiêu đề (lưu trữ hướng đi) và Nội dung mô tả chi tiết
            val title = extras.getCharSequence("android.title")?.toString() ?: ""
            val text = extras.getCharSequence("android.text")?.toString() ?: ""
            
            if (title.isNotEmpty() || text.isNotEmpty()) {
                val fullNavigationText = "$title -> $text"
                BleManager.addLog("Chặn được Maps: \"$fullNavigationText\"")
                
                // Gửi dữ liệu đã trích lọc đến Module xử lý Ble để gửi đi ESP32
                BleManager.sendLargeString(fullNavigationText)
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // Có thể bổ sung xử lý khi người dùng xóa thông báo (nếu cần thiết)
    }
}

package com.gpsble.bridge

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.*
import java.util.concurrent.ConcurrentLinkedQueue

@SuppressLint("StaticFieldLeak", "MissingPermission")
object BleManager {

    private lateinit var context: Context
    private var bluetoothManager: BluetoothManager? = null
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothGatt: BluetoothGatt? = null
    private var writeCharacteristic: BluetoothGattCharacteristic? = null
    
    private var savedMacAddress: String? = null
    private const val PREFS_NAME = "GPS_BLE_PREFS"
    private const val KEY_MAC_ADDR = "SAVED_ESP32_MAC"

    // Bộ lọc UUID cấu hình từ bảng điều khiển
    private val SERVICE_UUID: UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb")
    private val CHAR_UUID: UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")

    // Log live data mô phỏng đơn giản để hiển thị trong Compose UI
    val logLiveData = mutableListOf<(List<String>) -> Unit>()
    private val logList = mutableListOf<String>()

    private val mainHandler = Handler(Looper.getMainLooper())
    private var isScanning = false
    private var isConnected = false

    // Hàng đợi gửi dữ liệu tuần tự
    private val sendQueue = ConcurrentLinkedQueue<ByteArray>()
    private var isWriting = false

    fun init(context: Context) {
        this.context = context.applicationContext
        bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager?.adapter

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        savedMacAddress = prefs.getString(KEY_MAC_ADDR, null)
        if (savedMacAddress != null) {
            addLog("Đã tìm thấy địa chỉ MAC ESP32 lưu trữ: $savedMacAddress")
        }
    }

    fun addLog(msg: String) {
        mainHandler.post {
            val timestamp = java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            logList.add("[$timestamp] $msg")
            if (logList.size > 200) {
                logList.removeAt(0)
            }
            logLiveData.forEach { it(logList) }
        }
    }

    fun clearLog() {
        logList.clear()
        logLiveData.forEach { it(logList) }
    }

    fun startScanAndConnect() {
        val adapter = bluetoothAdapter
        if (adapter == null || !adapter.isEnabled) {
            addLog("Lỗi: Bluetooth đang tắt!")
            return
        }

        if (savedMacAddress != null) {
            addLog("Tự động ép kết nối lại tới MAC: $savedMacAddress...")
            connectToAddress(savedMacAddress!!)
            return
        }

        if (isScanning) return
        isScanning = true
        addLog("Đang quét thiết bị ESP32 (Chờ phát sóng)...")

        val scanner = adapter.bluetoothLeScanner
        scanner?.startScan(scanCallback)

        // Tự động dừng quét sau 15 giây
        mainHandler.postDelayed({
            if (isScanning) {
                stopScan()
                addLog("Dừng quét. Không tìm thấy thiết bị ESP32 mới.")
            }
        }, 15000)
    }

    private fun stopScan() {
        if (isScanning) {
            isScanning = false
            bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback)
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            val device = result?.device ?: return
            val name = device.name ?: ""
            // Nhận diện thiết bị có tên chưa "ESP32", "Chronos" hoặc có Service UUID mong đợi
            if (name.contains("ESP32", true) || name.contains("Chronos", true) || 
                result.scanRecord?.serviceUuids?.any { it.uuid == SERVICE_UUID } == true) {
                
                stopScan()
                addLog("Tìm thấy: $name ($device.address). Đang kết nối...")
                
                // Lưu địa chỉ MAC cho các lần sau
                saveMacAddress(device.address)
                connectToDevice(device)
            }
        }
    }

    private fun saveMacAddress(address: String) {
        savedMacAddress = address
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_MAC_ADDR, address).apply()
        addLog("Đã ghi nhớ địa chỉ MAC thiết bị: $address")
    }

    private fun connectToAddress(address: String) {
        val adapter = bluetoothAdapter
        if (adapter == null) return
        try {
            val device = adapter.getRemoteDevice(address)
            connectToDevice(device)
        } catch (e: Exception) {
            addLog("Lỗi khi tìm thiết bị lưu trữ: ${e.message}")
            savedMacAddress = null // Reset để quét lại
            startScanAndConnect()
        }
    }

    private fun connectToDevice(device: BluetoothDevice) {
        bluetoothGatt = device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                isConnected = true
                addLog("Đã kết nối Bluetooth tới ESP32!")
                addLog("Đang khám phá BLE Services...")
                gatt?.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                isConnected = false
                writeCharacteristic = null
                addLog("Đã mất kết nối. Đang chờ sóng để kết nối lại...")
                
                // Cơ chế tự động tìm lại cực nhạy
                mainHandler.postDelayed({
                    if (!isConnected) {
                        startScanAndConnect()
                    }
                }, 5000)
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                val service = gatt?.getService(SERVICE_UUID)
                if (service != null) {
                    writeCharacteristic = service.getCharacteristic(CHAR_UUID)
                    if (writeCharacteristic != null) {
                        addLog("Kênh giao tiếp BLE đã SẴN SÀNG!")
                    } else {
                        addLog("Lỗi: Không tìm thấy Characteristic tương thích.")
                    }
                } else {
                    addLog("Lỗi: Không khớp Service UUID trên ESP32.")
                }
            } else {
                addLog("Lỗi khám phá dịch vụ: $status")
            }
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt?, characteristic: BluetoothGattCharacteristic?, status: Int) {
            // Cho phép gửi gói tin tiếp theo khi viết hoàn tất
            isWriting = false
            processSendQueue()
        }
    }

    // Gửi chuỗi thông báo, tự động băm nhỏ thành các chunk <= 20 bytes
    fun sendLargeString(text: String) {
        if (!isConnected || writeCharacteristic == null) {
            addLog("Không thể gửi, ESP32 chưa kết nối.")
            return
        }

        val rawBytes = text.toByteArray(Charsets.UTF_8)
        val chunkSize = 20
        var offset = 0
        var chunkCount = 0

        while (offset < rawBytes.size) {
            val length = minOf(chunkSize, rawBytes.size - offset)
            val chunk = ByteArray(length)
            System.arraycopy(rawBytes, offset, chunk, 0, length)
            sendQueue.add(chunk)
            offset += length
            chunkCount++
        }

        addLog("Đã băm chỉ đường thành $chunkCount gói (MTU 20B). Đang gửi tuần tự...")
        processSendQueue()
    }

    private synchronized fun processSendQueue() {
        if (isWriting) return
        val chunk = sendQueue.poll() ?: return

        isWriting = true
        writeCharacteristic?.let { char ->
            char.value = chunk
            // BLE Write Type tùy thuộc vào cấu hình: thường write-no-response
            char.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            bluetoothGatt?.writeCharacteristic(char)
            
            // Log nội dung chunk ra UI Console
            val textSim = String(chunk, Charsets.UTF_8)
            addLog("Đang gửi chunk: \"$textSim\"")
        }

        // Delay đề phòng trường hợp callback onCharacteristicWrite không được thiết bị ESP32 gửi về kịp thời
        mainHandler.postDelayed({
            if (isWriting) {
                isWriting = false
                processSendQueue()
            }
        }, 150) // Delay 150ms tối ưu giữa các gói tránh Buffer Overflow
    }
}
